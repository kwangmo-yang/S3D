%% Initialization
tic
clc, clear
close all

currentFolder = pwd;

%% PL spectrum

cd([currentFolder '\PL'])

wavelength = 400:700;      % Range of wavelength
PL_Spectrum = readmatrix('5CzBN_PL_sampleA.txt');    % PL spectrum of thin film EML

VED = 0.25;    % Horizontal dipole orientation
PLQY = 1;      % PLQY of thin film EML

%% Variable reshaping

wavelength = reshape(wavelength, 1, 1, length(wavelength));

PL_Spectrum = interp1(PL_Spectrum(:,1), PL_Spectrum(:,2), wavelength);
PL_Spectrum = PL_Spectrum/trapz(PL_Spectrum);
PL_Spectrum = reshape(PL_Spectrum, 1,1,length(PL_Spectrum));
Air = [200 1920; 1.003 1.003];
Air = interp1(Air(1,:), Air(2,:), wavelength);

%% Refractive index

% Load refractive indices
cd([currentFolder '\nk'])

Glass = nk2epsilon(readmatrix('Glass.txt'), wavelength);
ITO = nk2epsilon(readmatrix('ITO.txt'), wavelength);
HATCN = nk2epsilon(readmatrix('HAT-CN.xlsx'), wavelength);
BCFN = nk2epsilon(readmatrix('BCFN.txt'), wavelength);
SiCzCz = nk2epsilon(readmatrix('SiCzCz.csv'), wavelength);
mSiTrz = nk2epsilon(readmatrix('mSiTrz.csv'), wavelength);
mSiTrz_Liq = nk2epsilon(readmatrix('mSiTrz_Liq.csv'), wavelength);
Liq = nk2epsilon(readmatrix('Liq.csv'), wavelength);
Al = nk2epsilon(readmatrix('Al.txt'), wavelength);
EML = nk2epsilon(readmatrix('EML.csv'), wavelength);

%% Structure

thickness = [inf 100 1.5 40 5 30 5 60 10 150 700000 inf]; % Layer thicknesses (nm)
epsilon = [Air; Al; Liq; mSiTrz_Liq; mSiTrz; EML; SiCzCz; BCFN; HATCN; ITO; Glass; Air]; % Layer materials

EML_position = 6; % Position of EML
CTL_position = 4; % Position of target CTL for thickness variation

CTL_thickness = 100:115; % Range of CTL thickness to scan

Delta_x = 5; % Spatial interval

%% Variable initialization

thickness = thickness * 1e-9;
dipole_position_array = (0 : Delta_x : thickness(EML_position)*1e9) * 1e-9;

x_res = 1.25e-3;
x_real = (-pi/2 : x_res : -x_res); % this is for the u=0 to u=1 region, it is negative so that u is continuous from x_real to x_imag
x_imag = 1i * (x_res : 10*x_res : pi/2); % this is the u>1 region, change the upper bound to get more accurate calculations of non-rad energy transfer very close to a metal

% If the upper bound is too large, calculation diverges
x = [x_real x_imag];
u_Purcell = cos(x); % u is the normalized surface-parallel wavevector

k = 2 * pi * sqrt(epsilon)./(wavelength*1e-9);

% surface perpendicular wavevector
h_Purcell = k(EML_position,:,:).*sqrt(epsilon./epsilon(EML_position,:,:)-u_Purcell.^2);

theta_air = 0 : pi / 180 : 89 * pi / 180;
u_air = sin(theta_air).* k(end,:,:)./ k(EML_position,:,:);
h_air = k(EML_position,:,:).* sqrt(epsilon./ epsilon(EML_position,:,:) - u_air.^2);

%% Calculation

cd(currentFolder)

min_res = zeros(length(CTL_thickness), 1);
n = length(dipole_position_array);
options = optimoptions('lsqlin', 'Display', 'off', ...
    'Algorithm', 'interior-point', ...
    'OptimalityTolerance', 1e-12, ...
    'StepTolerance', 1e-12);
lb = zeros(1, n-1);

for i = 1:length(CTL_thickness)

    thickness(CTL_position) = CTL_thickness(i)*1e-9;

    [K_TM_v, K_TM_h, K_TE_h, F_TM_v, F_TM_h, F_TE_h] = Purcell_bottom( ...
        epsilon, thickness, EML_position, dipole_position_array, u_Purcell, h_Purcell);
    [I_TM, I_TE, Out_Effi, U] = Spectrum_bottom( ...
        F_TM_v, F_TM_h, F_TE_h, PL_Spectrum, VED, PLQY, ...
        wavelength, epsilon, thickness, EML_position, dipole_position_array, ...
        u_air, h_air, theta_air);
    I_total = I_TM + I_TE;
    A_ex = abs(squeeze(I_total(:, 1, :)))';

    res_test = zeros(n, 1);
    for j = 1:n
        test_i = A_ex(:, j);
        V_minus_i = A_ex(:, setdiff(1:n, j));
        answer = lsqlin(V_minus_i, test_i, [],[],[],[],lb,[],[],options);
        res_test(j) = norm(test_i-V_minus_i*answer)/norm(test_i);
    end
    min_res(i) = min(res_test);
    disp("CTL thickness: " + num2str(CTL_thickness(i)) + " nm")
end

%% Plot

plot(CTL_thickness, min_res*100, 'k', 'LineWidth', 2)
yline(3, ':', 'LineWidth', 1.5)

xlabel('CTL thickness (nm)', 'FontSize', 16), ylabel('min({\bfr}) (%)', 'FontSize', 16)

toc

%% n, k to epsilon

function epsilon = nk2epsilon(nk, wavelength)
epsilon = [nk(:,1)'; nk(:,2)'.^2 - nk(:,3)'.^2 + 2*1i*nk(:,2)'.* nk(:,3)'];
epsilon = interp1(epsilon(1,:), epsilon(2,:), wavelength, 'spline', 'extrap');
end