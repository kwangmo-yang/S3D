function [I_TM, I_TE, Out_Effi, U] = Spectrum_bottom( ...
    F_TM_v, F_TM_h, F_TE_h, PL_Spectrum, VED, PLQY, ...
    wavelength, epsilon, thickness, dipole_layer, dipole_position_array, u, h, theta_air)

%%

N=size(thickness, 2);

HED = 1 - VED;

%% Upward
for n = N:-1:2 % n-1 to n

    r_TE(n,:,:) = (h(n-1,:,:) - h(n,:,:))./ (h(n-1,:,:) + h(n,:,:));
    t_TE(n,:,:) = 1 + r_TE(n,:,:);
    r_TM(n,:,:) = (h(n-1,:,:)./ epsilon(n-1,:,:) - h(n,:,:)./ epsilon(n,:,:))./ (h(n-1,:,:)./ epsilon(n-1,:,:) + h(n,:,:)./ epsilon(n,:,:));
    t_TM(n,:,:) = (1 + r_TM(n,:,:)).* sqrt(epsilon(n-1,:,:)./epsilon(n,:,:));

end

r_TE_up(N-2,:,:) = r_TE(N-1,:,:);
r_TM_up(N-2,:,:) = r_TM(N-1,:,:);
t_TE_up(N-2,:,:) = t_TE(N-1,:,:);
t_TM_up(N-2,:,:) = t_TM(N-1,:,:);

for n = N-3 : -1 : dipole_layer

    r_TE_up(n,:,:) = (r_TE(n+1,:,:) + r_TE_up(n+1,:,:).* exp(2j * h(n+1,:,:) * thickness(n+1)))./ (1 + r_TE(n+1,:,:).* r_TE_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)));
    r_TM_up(n,:,:) = (r_TM(n+1,:,:) + r_TM_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)))./ (1 + r_TM(n+1,:,:).* r_TM_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)));
    t_TE_up(n,:,:) = (t_TE(n+1,:,:).* t_TE_up(n+1,:,:).* exp(1j * h(n+1,:,:).* thickness(n+1)))./ (1 + r_TE(n+1,:,:).* r_TE_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)));
    t_TM_up(n,:,:) = (t_TM(n+1,:,:).* t_TM_up(n+1,:,:).* exp(1j * h(n+1,:,:).* thickness(n+1)))./ (1 + r_TM(n+1,:,:).* r_TM_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)));

end


% Ts,o // the reflectance and the transmittance of the substrate outer medium interface
T_TE_Glass_Air = h(N,:,:)./ h(N-1,:,:).* t_TE(N,:,:).^2;
T_TM_Glass_Air = h(N,:,:)./ h(N-1,:,:).* t_TM(N,:,:).^2;

% Rs,o
R_TE_Glass_Air = r_TE(N,:,:).^2;
R_TM_Glass_Air = r_TM(N,:,:).^2;

% T+ // the energy transmittance of the top half stack
T_TE_EML_Glass = h(N-1,:,:)./ h(dipole_layer,:,:).* abs(t_TE_up(dipole_layer,:,:)).^2;
T_TM_EML_Glass = h(N-1,:,:)./ h(dipole_layer,:,:).* abs(t_TM_up(dipole_layer,:,:)).^2;

%% Downward
for n = 1 : N-1 % if n = 2, 3 to 2

    r_TE(n,:,:) = (h(n+1,:,:) - h(n,:,:))./ (h(n+1,:,:) + h(n,:,:));
    t_TE(n,:,:) = 1 + r_TE(n,:,:);
    r_TM(n,:,:) = (h(n+1,:,:)./ epsilon(n+1,:,:) - h(n,:,:)./ epsilon(n,:,:))./ (h(n+1,:,:)./ epsilon(n+1,:,:) + h(n,:,:)./ epsilon(n,:,:));
    t_TM(n,:,:) = (1 + r_TM(n,:,:)).* sqrt(epsilon(n+1,:,:)./epsilon(n,:,:));

end

r_TE_down(2,:,:) = r_TE(1,:,:);
r_TM_down(2,:,:) = r_TM(1,:,:);
t_TE_down(2,:,:) = t_TE(1,:,:);
t_TM_down(2,:,:) = t_TM(1,:,:);

for n = 3 : N

    r_TE_down(n,:,:) = (r_TE(n-1,:,:) + r_TE_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)))./ (1 + r_TE(n-1,:,:).* r_TE_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)));
    r_TM_down(n,:,:) = (r_TM(n-1,:,:) + r_TM_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)))./ (1 + r_TM(n-1,:,:).* r_TM_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)));
    t_TE_down(n,:,:) = (t_TE(n-1,:,:).* t_TE_down(n-1,:,:).* exp(1j * h(n-1,:,:).* thickness(n-1)))./ (1 + r_TE(n-1,:,:).* r_TE_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)));
    t_TM_down(n,:,:) = (t_TM(n-1,:,:).* t_TM_down(n-1,:,:).* exp(1j * h(n-1,:,:).* thickness(n-1)))./ (1 + r_TM(n-1,:,:).* r_TM_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)));

end


% Rc // reflectance of the optically thin layers in the OLED stack, including the interface between the las coherent layer(ITO) and the incoherent substrate(Glass)
R_c_TE = abs(r_TE_down(N-1,:,:,:)).^2;
R_c_TM = abs(r_TM_down(N-1,:,:,:)).^2;

%% Dipole position
for y = length(dipole_position_array):-1:1

    dipole_position = dipole_position_array(y); % distance from interface with previous layer

    a_up_TM(y,:,:) = r_TM_up(dipole_layer,:,:).* exp(2j * h(dipole_layer,:,:) * dipole_position);
    a_up_TE(y,:,:) = r_TE_up(dipole_layer,:,:).* exp(2j * h(dipole_layer,:,:) * dipole_position);


    a_down_TM(y,:,:) = r_TM_down(dipole_layer,:,:).* exp(2j * h(dipole_layer,:,:) * (thickness(dipole_layer) - dipole_position));
    a_down_TE(y,:,:) = r_TE_down(dipole_layer,:,:).* exp(2j * h(dipole_layer,:,:) * (thickness(dipole_layer) - dipole_position));

end

a_TM = a_up_TM.*a_down_TM;
a_TE = a_up_TE.*a_down_TE;

%%
% Outcoupled power fractions radiated into the substrate
K_TM_v = 3 / 8 * u.^2./ sqrt(1 - u.^2).* abs(1 + a_down_TM).^2./ abs(1 - a_TM).^2.* T_TM_EML_Glass;
K_TM_h = 3 / 16 * sqrt(1 - u.^2).* abs(1 - a_down_TM).^2./ abs(1 - a_TM).^2.* T_TM_EML_Glass;
K_TE_h = 3 / 16 * 1./ sqrt(1 - u.^2).* abs(1 + a_down_TE).^2./ abs(1 - a_TE).^2.* T_TE_EML_Glass;

% Fraction of power effectively radiated in a far field medium by considering incoherent multiple reflections of field intensities in the optically thick substrate.
K_Out_TM_v = K_TM_v.* T_TM_Glass_Air./ (1 - R_TM_Glass_Air.* R_c_TM);
K_Out_TM_h = K_TM_h.* T_TM_Glass_Air./ (1 - R_TM_Glass_Air.* R_c_TM);
K_Out_TE_h = K_TE_h.* T_TE_Glass_Air./ (1 - R_TE_Glass_Air.* R_c_TE);

% Outcoupled power spectrum per unit solid angle
P_Out_TM_v = epsilon(N,:,:)./ epsilon(dipole_layer,:,:).* cos(theta_air) / pi.* K_Out_TM_v;
P_Out_TM_h = epsilon(N,:,:)./ epsilon(dipole_layer,:,:).* cos(theta_air) / pi.* K_Out_TM_h;
P_Out_TE_h = epsilon(N,:,:)./ epsilon(dipole_layer,:,:).* cos(theta_air) / pi.* K_Out_TE_h;

P_Out = P_Out_TM_v * VED + (P_Out_TE_h + P_Out_TM_h) * HED;

% Purcell factor (weighted by dipole orientation ratio
F = F_TM_v * VED + (F_TM_h + F_TE_h) * HED;

% spectral radiant intensity per unit area
I_TM_v = 1240./ wavelength.* PL_Spectrum.* PLQY./(F*PLQY+(1-PLQY)).* P_Out_TM_v;
I_TM_h = 1240./ wavelength.* PL_Spectrum.* PLQY./(F*PLQY+(1-PLQY)).* P_Out_TM_h;
I_TE_h = 1240./ wavelength.* PL_Spectrum.* PLQY./(F*PLQY+(1-PLQY)).* P_Out_TE_h;

I_TM = I_TM_v * VED + I_TM_h * HED;
I_TE = I_TE_h * HED;

%%

U = pi^2 / 90 * trapz(rad2deg(theta_air), sin(theta_air) .* P_Out, 2);

Out_Effi = squeeze(trapz(PL_Spectrum .* PLQY./(F*PLQY+(1-PLQY)) .* U, 3));

end