%% Initialization

clc, clear
close all

currentFolder = pwd;

%% PL spectrum

cd([currentFolder '\PL'])

wavelength = 400:700;      % Range of wavelength
PL_Spectrum = readmatrix('5CzBN_PL_sampleA.txt');    % PL spectrum of thin film EML

VED = 0.25;    % Horizontal dipole orientation
PLQY = 1;      % PLQY of thin film EML

%% EL spectrum

cd([currentFolder '\EL'])

EL_Spectrum = readmatrix('5CzBN_EL_ETL_109_sampleA.txt');    % EL spectrum of CTL-thickness-modulated device

%% Variable reshaping

I_EL = interp1(EL_Spectrum(:, 1), EL_Spectrum(:, 2), wavelength);
I_EL = I_EL' / max(I_EL);

wavelength = reshape(wavelength, 1, 1, length(wavelength));

PL_Spectrum = interp1(PL_Spectrum(:,1), PL_Spectrum(:,2), wavelength);
PL_Spectrum = PL_Spectrum/trapz(PL_Spectrum);
PL_Spectrum = reshape(PL_Spectrum, 1,1,length(PL_Spectrum));
Air = [200 1920; 1.003 1.003];
Air = interp1(Air(1,:), Air(2,:), wavelength);

%% Refractive index

% Load refractive indices
cd([currentFolder '\nk'])

Glass = nk2epsilon(readmatrix('Glass.txt'), wavelength);
ITO = nk2epsilon(readmatrix('ITO.txt'), wavelength);
HATCN = nk2epsilon(readmatrix('HAT-CN.xlsx'), wavelength);
BCFN = nk2epsilon(readmatrix('BCFN.txt'), wavelength);
SiCzCz = nk2epsilon(readmatrix('SiCzCz.csv'), wavelength);
mSiTrz = nk2epsilon(readmatrix('mSiTrz.csv'), wavelength);
mSiTrz_Liq = nk2epsilon(readmatrix('mSiTrz_Liq.csv'), wavelength);
Liq = nk2epsilon(readmatrix('Liq.csv'), wavelength);
Al = nk2epsilon(readmatrix('Al.txt'), wavelength);
EML = nk2epsilon(readmatrix('EML.csv'), wavelength);

%% Structure

thickness = [inf 100 1.5 109 5 30 5 60 10 150 700000 inf]; % Layer thicknesses (nm)
epsilon = [Air; Al; Liq; mSiTrz_Liq; mSiTrz; EML; SiCzCz; BCFN; HATCN; ITO; Glass; Air]; % Layer materials

EML_position = 6; % Position of EML

Delta_x = 5; % Spatial interval

%% Variable initialization

thickness = thickness * 1e-9;
dipole_position_array = (0 : Delta_x : thickness(EML_position)*1e9) * 1e-9;

x_res = 1.25e-3;
x_real = (-pi/2 : x_res : -x_res); % this is for the u=0 to u=1 region, it is negative so that u is continuous from x_real to x_imag
x_imag = 1i * (x_res : 10*x_res : pi/2); % this is the u>1 region, change the upper bound to get more accurate calculations of non-rad energy transfer very close to a metal

% If the upper bound is too large, calculation diverges
x = [x_real x_imag];
u_Purcell = cos(x); % u is the normalized surface-parallel wavevector

k = 2 * pi * sqrt(epsilon)./(wavelength*1e-9);

% surface perpendicular wavevector
h_Purcell = k(EML_position,:,:).*sqrt(epsilon./epsilon(EML_position,:,:)-u_Purcell.^2);

theta_air = 0 : pi / 180 : 89 * pi / 180;
u_air = sin(theta_air).* k(end,:,:)./ k(EML_position,:,:);
h_air = k(EML_position,:,:).* sqrt(epsilon./ epsilon(EML_position,:,:) - u_air.^2);

%% A_ex calculation

cd(currentFolder)

[K_TM_v, K_TM_h, K_TE_h, F_TM_v, F_TM_h, F_TE_h] = Purcell_bottom( ...
    epsilon, thickness, EML_position, dipole_position_array, u_Purcell, h_Purcell);
[I_TM, I_TE, Out_Effi, U] = Spectrum_bottom( ...
    F_TM_v, F_TM_h, F_TE_h, PL_Spectrum, VED, PLQY, ...
    wavelength, epsilon, thickness, EML_position, dipole_position_array, ...
    u_air, h_air, theta_air);
I_total = I_TM + I_TE;
A_ex = abs(squeeze(I_total(:, 1, :)))';

A_ex = A_ex / max(A_ex, [], 'all');

%% Fitting

alphalist = 0:0.05:2;

n = length(dipole_position_array);
x0 = ones(n, 1);
lb = zeros(size(x0));
ub = 2*ones(size(x0));
options = optimoptions('lsqnonlin', 'Display', 'off');

Exc_all = zeros(length(alphalist), n);
resnorm = zeros(length(alphalist), 1);

for i = 1:length(alphalist)

    alpha = alphalist(i);
    fun = @(r)([A_ex; alpha^2*eye(n)]*r - [I_EL; zeros(n, 1)]);
    [Exc, resnorm(i)] = lsqnonlin(fun, x0, lb, ub, options);
    Exc_all(i, :) = Exc/trapz(Exc);

end

solnorm = vecnorm(Exc_all, 2, 2);
[~, idx] = min(resnorm.^2 + solnorm.^2);
alpha_final = alphalist(idx);

%% Plot

f1 = figure(1);
tiledlayout(1, 2)

gcol = [0 0 180] / 255;

nexttile(1)
rectangle('Position', [-5 0 5 5], 'FaceColor', [125 158 134]/255, 'LineStyle', 'none')    
rectangle('Position', [dipole_position_array(end)*1e9 0 5 5], 'FaceColor', [166 146 131]/255, 'LineStyle', 'none')
hold on, box on

h = plot(dipole_position_array*1e9, Exc_all(idx, :));
h.Color = gcol;
h.LineWidth = 2.5;
h.Marker = 's';
h.MarkerFaceColor = h.Color;

xlim([-2 dipole_position_array(end)*1e9+2]), ylim([0 max(Exc_all(idx, :))*1.1])
xlabel('{\itx} (nm)', 'FontSize', 16), ylabel('{\itN}({\itx}) (a.u.)', 'FontSize', 16)

nexttile(2)
h = plot(squeeze(wavelength), I_EL);
h.Color = gcol;
h.LineWidth = 2.5;
h.Marker = 's';
h.MarkerFaceColor = h.Color;
h.MarkerIndices = 1:20:length(I_EL);
hold on

I_fit = A_ex*Exc_all(idx, :)';
h = plot(squeeze(wavelength), I_fit / max(I_fit));
h.Color = [gcol 0.5];
h.LineWidth = 5;
xlabel('Wavelength (nm)', 'FontSize', 16), ylabel('Normalized intensity (a.u.)', 'FontSize', 16), ylim([0 1.1])
legend('{\itI}_{EL}', 'Fit')

%% n, k to epsilon

function epsilon = nk2epsilon(nk, wavelength)
epsilon = [nk(:,1)'; nk(:,2)'.^2 - nk(:,3)'.^2 + 2*1i*nk(:,2)'.* nk(:,3)'];
epsilon = interp1(epsilon(1,:), epsilon(2,:), wavelength, 'spline', 'extrap');
end