function [K_TM_v, K_TM_h, K_TE_h, F_TM_v, F_TM_h, F_TE_h] = Purcell_bottom( ...
    epsilon, thickness, dipole_layer, dipole_position_array, u, h)

%%

N=size(thickness, 2);

%% Upward
for n = N:-1:2 % n-1 to n

    r_TE(n,:,:) = (h(n-1,:,:) - h(n,:,:))./ (h(n-1,:,:) + h(n,:,:));
    t_TE(n,:,:) = 1 + r_TE(n,:,:);
    r_TM(n,:,:) = (h(n-1,:,:)./ epsilon(n-1,:,:) - h(n,:,:)./ epsilon(n,:,:))./ (h(n-1,:,:)./ epsilon(n-1,:,:) + h(n,:,:)./ epsilon(n,:,:));
    t_TM(n,:,:) = (1 + r_TM(n,:,:)).* sqrt(epsilon(n-1,:,:)./epsilon(n,:,:));

end

r_TE_up(N-2,:,:) = r_TE(N-1,:,:);
r_TM_up(N-2,:,:) = r_TM(N-1,:,:);
t_TE_up(N-2,:,:) = t_TE(N-1,:,:);
t_TM_up(N-2,:,:) = t_TM(N-1,:,:);

for n = N-3 : -1 : dipole_layer

    r_TE_up(n,:,:) = (r_TE(n+1,:,:) + r_TE_up(n+1,:,:).* exp(2j * h(n+1,:,:) * thickness(n+1)))./ (1 + r_TE(n+1,:,:).* r_TE_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)));
    r_TM_up(n,:,:) = (r_TM(n+1,:,:) + r_TM_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)))./ (1 + r_TM(n+1,:,:).* r_TM_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)));
    t_TE_up(n,:,:) = (t_TE(n+1,:,:).* t_TE_up(n+1,:,:).* exp(1j * h(n+1,:,:).* thickness(n+1)))./ (1 + r_TE(n+1,:,:).* r_TE_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)));
    t_TM_up(n,:,:) = (t_TM(n+1,:,:).* t_TM_up(n+1,:,:).* exp(1j * h(n+1,:,:).* thickness(n+1)))./ (1 + r_TM(n+1,:,:).* r_TM_up(n+1,:,:).* exp(2j * h(n+1,:,:).* thickness(n+1)));

end


%% Downward
for n = 1 : N-1 % if n = 2, 3 to 2

    r_TE(n,:,:) = (h(n+1,:,:) - h(n,:,:))./ (h(n+1,:,:) + h(n,:,:));
    t_TE(n,:,:) = 1 + r_TE(n,:,:);
    r_TM(n,:,:) = (h(n+1,:,:)./ epsilon(n+1,:,:) - h(n,:,:)./ epsilon(n,:,:))./ (h(n+1,:,:)./ epsilon(n+1,:,:) + h(n,:,:)./ epsilon(n,:,:));
    t_TM(n,:,:) = (1 + r_TM(n,:,:)).* sqrt(epsilon(n+1,:,:)./epsilon(n,:,:));

end

r_TE_down(2,:,:) = r_TE(1,:,:);
r_TM_down(2,:,:) = r_TM(1,:,:);
t_TE_down(2,:,:) = t_TE(1,:,:);
t_TM_down(2,:,:) = t_TM(1,:,:);

for n = 3 : dipole_layer

    r_TE_down(n,:,:) = (r_TE(n-1,:,:) + r_TE_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)))./ (1 + r_TE(n-1,:,:).* r_TE_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)));
    r_TM_down(n,:,:) = (r_TM(n-1,:,:) + r_TM_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)))./ (1 + r_TM(n-1,:,:).* r_TM_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)));
    t_TE_down(n,:,:) = (t_TE(n-1,:,:).* t_TE_down(n-1,:,:).* exp(1j * h(n-1,:,:).* thickness(n-1)))./ (1 + r_TE(n-1,:,:).* r_TE_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)));
    t_TM_down(n,:,:) = (t_TM(n-1,:,:).* t_TM_down(n-1,:,:).* exp(1j * h(n-1,:,:).* thickness(n-1)))./ (1 + r_TM(n-1,:,:).* r_TM_down(n-1,:,:).* exp(2j * h(n-1,:,:).* thickness(n-1)));

end


%% Purcell factor
a_up_TE = zeros([length(dipole_position_array) size(squeeze(h(dipole_layer,:,:)))]);
a_up_TM = zeros([length(dipole_position_array) size(squeeze(h(dipole_layer,:,:)))]);
a_down_TE = zeros([length(dipole_position_array) size(squeeze(h(dipole_layer,:,:)))]);
a_down_TM = zeros([length(dipole_position_array) size(squeeze(h(dipole_layer,:,:)))]);

for y = 1:length(dipole_position_array)

    dipole_position = dipole_position_array(y); % distance from interface with previous layer

    a_up_TM(y,:,:) = r_TM_up(dipole_layer,:,:).* exp(2j * h(dipole_layer,:,:) * dipole_position);
    a_up_TE(y,:,:) = r_TE_up(dipole_layer,:,:).* exp(2j * h(dipole_layer,:,:) * dipole_position);


    a_down_TM(y,:,:) = r_TM_down(dipole_layer,:,:).* exp(2j * h(dipole_layer,:,:) * (thickness(dipole_layer) - dipole_position));
    a_down_TE(y,:,:) = r_TE_down(dipole_layer,:,:).* exp(2j * h(dipole_layer,:,:) * (thickness(dipole_layer) - dipole_position));


end


a_TM = a_up_TM.*a_down_TM;
a_TE = a_up_TE.*a_down_TE;

%%
% power densities radiated by the two dipole sources per unit wavelength lamda
K_TM_v = 3 / 4 * real(u.^2./ sqrt(1 - u.^2).* (1 + a_up_TM).* (1 + a_down_TM)./ (1 - a_TM));
K_TM_h = 3 / 8 * real(sqrt(1 - u.^2).* (1 - a_up_TM).* (1 - a_down_TM)./ (1 - a_TM));
K_TE_h = 3 / 8 * real(1./ sqrt(1 - u.^2).* (1 + a_up_TE).* (1 + a_down_TE)./ (1 - a_TE));

% total radiated power // the effect of the optical environment
F_TM_v = trapz(u, 2 * u.* K_TM_v, 2);
F_TM_h = trapz(u, 2 * u.* K_TM_h, 2);
F_TE_h = trapz(u, 2 * u.* K_TE_h, 2);

end