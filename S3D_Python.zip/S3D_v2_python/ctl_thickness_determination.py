
from __future__ import annotations
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import lsq_linear

from config import S3DConfig, build_epsilon, load_pl
from core import purcell_bottom, spectrum_bottom


def main():
    base_dir = Path(__file__).resolve().parent

    cfg = S3DConfig(
        wavelength=np.arange(400, 701, 1, dtype=float),
        pl_filename='5CzBN_PL_sampleA.txt',
        el_filename=None,
        ved=0.25,
        plqy=1.0,
        thickness_nm=np.array([np.inf, 100, 1.5, 40, 5, 30, 5, 60, 10, 150, 700000, np.inf], dtype=float),
        eml_position_1based=6,
        ctl_position_1based=4,
        ctl_scan_nm=np.arange(30, 131, 1, dtype=float),
        delta_x_nm=5.0,
    )

    wavelength = cfg.wavelength
    pl_spectrum = load_pl(base_dir, cfg.pl_filename, wavelength)
    epsilon = build_epsilon(base_dir, wavelength)
    thickness = cfg.thickness_nm * 1e-9

    eml_idx = cfg.eml_position_1based - 1
    ctl_idx = cfg.ctl_position_1based - 1
    dipole_position_array = np.arange(0, cfg.thickness_nm[cfg.eml_position_1based - 1] + cfg.delta_x_nm, cfg.delta_x_nm) * 1e-9

    x_res = 1.25e-3
    x_real = np.arange(-np.pi / 2, -x_res + 1e-15, x_res)
    x_imag = 1j * np.arange(x_res, np.pi / 2 + 1e-15, 10 * x_res)
    x = np.concatenate([x_real, x_imag])
    u_purcell = np.cos(x)

    k = 2 * np.pi * np.sqrt(epsilon) / (wavelength[None, :] * 1e-9)
    h_purcell = k[eml_idx][None, :] * np.sqrt(epsilon[:, None, :] / epsilon[eml_idx][None, None, :] - u_purcell[:, None] ** 2)

    theta_air = np.deg2rad(np.arange(0, 90, 1, dtype=float))
    u_air = np.sin(theta_air)[:, None] * k[-1][None, :] / k[eml_idx][None, :]
    h_air = k[eml_idx][None, :] * np.sqrt(epsilon[:, None, :] / epsilon[eml_idx][None, None, :] - u_air[None, :, :] ** 2)

    min_res = np.zeros_like(cfg.ctl_scan_nm)
    n_pos = dipole_position_array.size

    for i, ctl_nm in enumerate(cfg.ctl_scan_nm):
        thickness_i = thickness.copy()
        thickness_i[ctl_idx] = ctl_nm * 1e-9

        _, _, _, f_tm_v, f_tm_h, f_te_h = purcell_bottom(
            epsilon=epsilon,
            thickness=thickness_i,
            dipole_layer=eml_idx,
            dipole_position_array=dipole_position_array,
            u=u_purcell,
            h=h_purcell,
        )

        i_tm, i_te, _, _ = spectrum_bottom(
            f_tm_v=f_tm_v,
            f_tm_h=f_tm_h,
            f_te_h=f_te_h,
            pl_spectrum=pl_spectrum,
            ved=cfg.ved,
            plqy=cfg.plqy,
            wavelength=wavelength,
            epsilon=epsilon,
            thickness=thickness_i,
            dipole_layer=eml_idx,
            dipole_position_array=dipole_position_array,
            u=u_air,
            h=h_air,
            theta_air=theta_air,
        )

        i_total = i_tm + i_te
        a_ex = np.abs(i_total[:, 0, :]).T

        res_test = np.zeros(n_pos)
        for j in range(n_pos):
            test_i = a_ex[:, j]
            v_minus_i = np.delete(a_ex, j, axis=1)
            ans = lsq_linear(v_minus_i, test_i, bounds=(0, np.inf), lsmr_tol='auto')
            res_test[j] = np.linalg.norm(test_i - v_minus_i @ ans.x) / np.linalg.norm(test_i)

        min_res[i] = np.min(res_test)
        print(f'CTL thickness: {ctl_nm:.0f} nm')

    plt.figure(figsize=(6, 4))
    plt.plot(cfg.ctl_scan_nm, min_res * 100, 'k', linewidth=2)
    plt.axhline(3, linestyle=':', linewidth=1.5)
    plt.xlabel('CTL thickness (nm)')
    plt.ylabel('min($r_i$) (%)')
    plt.tight_layout()
    plt.show()


if __name__ == '__main__':
    main()
