from __future__ import annotations
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import least_squares

from config import S3DConfig, build_epsilon, load_pl, load_el
from core import purcell_bottom, spectrum_bottom


def main():
    base_dir = Path(__file__).resolve().parent

    cfg = S3DConfig(
        wavelength=np.arange(400, 701, 1, dtype=float),
        pl_filename='5CzBN_PL_sampleB.txt',
        el_filename='5CzBN_EL_ETL_109_sampleB.txt',
        ved=0.25,
        plqy=1.0,
        thickness_nm=np.array([np.inf, 100, 1.5, 109, 5, 30, 5, 60, 10, 150, 700000, np.inf], dtype=float),
        eml_position_1based=6,
        delta_x_nm=5.0,
    )

    wavelength = cfg.wavelength
    pl_spectrum = load_pl(base_dir, cfg.pl_filename, wavelength)
    i_el = load_el(base_dir, cfg.el_filename, wavelength)
    epsilon = build_epsilon(base_dir, wavelength)
    thickness = cfg.thickness_nm * 1e-9

    eml_idx = cfg.eml_position_1based - 1
    dipole_position_array = np.arange(
        0,
        cfg.thickness_nm[cfg.eml_position_1based - 1] + cfg.delta_x_nm,
        cfg.delta_x_nm
    ) * 1e-9

    x_res = 1.25e-3
    x_real = np.arange(-np.pi / 2, -x_res + 1e-15, x_res)
    x_imag = 1j * np.arange(x_res, np.pi / 2 + 1e-15, 10 * x_res)
    x = np.concatenate([x_real, x_imag])
    u_purcell = np.cos(x)

    k = 2 * np.pi * np.sqrt(epsilon) / (wavelength[None, :] * 1e-9)

    h_purcell = k[eml_idx][None, :] * np.sqrt(
        epsilon[:, None, :] / epsilon[eml_idx][None, None, :] - u_purcell[:, None] ** 2
    )

    theta_air = np.deg2rad(np.arange(0, 90, 1, dtype=float))
    u_air = np.sin(theta_air)[:, None] * k[-1][None, :] / k[eml_idx][None, :]
    h_air = k[eml_idx][None, :] * np.sqrt(
        epsilon[:, None, :] / epsilon[eml_idx][None, None, :] - u_air[None, :, :] ** 2
    )

    _, _, _, f_tm_v, f_tm_h, f_te_h = purcell_bottom(
        epsilon=epsilon,
        thickness=thickness,
        dipole_layer=eml_idx,
        dipole_position_array=dipole_position_array,
        u=u_purcell,
        h=h_purcell,
    )

    i_tm, i_te, _, _ = spectrum_bottom(
        f_tm_v=f_tm_v,
        f_tm_h=f_tm_h,
        f_te_h=f_te_h,
        pl_spectrum=pl_spectrum,
        ved=cfg.ved,
        plqy=cfg.plqy,
        wavelength=wavelength,
        epsilon=epsilon,
        thickness=thickness,
        dipole_layer=eml_idx,
        dipole_position_array=dipole_position_array,
        u=u_air,
        h=h_air,
        theta_air=theta_air,
    )

    i_total = i_tm + i_te
    a_ex = np.abs(i_total[:, 0, :]).T
    a_ex = a_ex / np.max(a_ex)

    alphalist = np.arange(0, 1.0001, 0.05)
    n_pos = dipole_position_array.size
    x0 = np.ones(n_pos)
    bounds = (np.zeros(n_pos), 2 * np.ones(n_pos))

    exc_all = np.zeros((alphalist.size, n_pos))
    resnorm = np.zeros(alphalist.size)

    eye = np.eye(n_pos)
    zeros = np.zeros(n_pos)

    for i, alpha in enumerate(alphalist):
        a_aug = np.vstack([a_ex, alpha ** 2 * eye])
        b_aug = np.concatenate([i_el, zeros])

        def residual(r):
            return a_aug @ r - b_aug

        res = least_squares(residual, x0, bounds=bounds)
        exc = res.x
        exc_all[i, :] = exc / np.trapz(exc, x=dipole_position_array)
        resnorm[i] = np.sum(res.fun ** 2)

    solnorm = np.linalg.norm(exc_all, axis=1)
    score = resnorm ** 2 / np.max(resnorm) ** 2 + solnorm ** 2 / np.max(solnorm) ** 2
    idx = int(np.argmin(score))

    plt.figure(figsize=(10, 4))

    plt.subplot(1, 2, 1)
    plt.axvspan(-5, 0, ymin=0, ymax=1, color=np.array([125, 158, 134]) / 255.0)
    plt.axvspan(
        dipole_position_array[-1] * 1e9,
        dipole_position_array[-1] * 1e9 + 5,
        ymin=0,
        ymax=1,
        color=np.array([166, 146, 131]) / 255.0
    )
    plt.plot(
        dipole_position_array * 1e9,
        exc_all[idx, :],
        color=np.array([0, 0, 180]) / 255.0,
        linewidth=2.5,
        marker='s'
    )
    plt.xlim([-2, dipole_position_array[-1] * 1e9 + 2])
    plt.ylim([0, np.max(exc_all[idx, :]) * 1.1])
    plt.xlabel('$x$ (nm)')
    plt.ylabel('$N(x)$ (a.u.)')

    plt.subplot(1, 2, 2)
    plt.plot(
        wavelength,
        i_el,
        color=np.array([0, 0, 180]) / 255.0,
        linewidth=2.5,
        marker='s',
        markevery=20,
        label='$I_{EL}$'
    )
    i_rec = a_ex @ exc_all[idx, :]
    plt.plot(
        wavelength,
        i_rec / np.max(i_rec),
        color=(0/255, 0/255, 180/255, 0.5),
        linewidth=5,
        label='Fit'
    )
    plt.xlabel('Wavelength (nm)')
    plt.ylabel('Normalized intensity (a.u.)')
    plt.ylim([0, 1.1])
    plt.legend()

    plt.tight_layout()
    plt.show()


if __name__ == '__main__':
    main()