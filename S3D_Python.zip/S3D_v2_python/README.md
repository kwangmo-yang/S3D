
# S3D_v2 Python conversion

This folder is a Python port of the MATLAB files in the uploaded archive.

## Converted files
- `core.py` ← `Purcell_bottom.m`, `Spectrum_bottom.m`
- `ctl_thickness_determination.py` ← `CTL_thickness_determination.m`
- `rz_extraction.py` ← `RZ_extraction.m`
- `config.py`, `io_utils.py` ← helper utilities for loading nk/PL/EL files

## Required packages
```bash
pip install numpy scipy pandas matplotlib openpyxl
```

## Run
```bash
python ctl_thickness_determination.py
python rz_extraction.py
```

## Notes
- MATLAB 1-based layer indices were converted to Python 0-based indices internally.
- GPU logic was not ported; this version is CPU-only.
- Interpolation uses `scipy.interpolate.interp1d`.
- `lsqlin` was replaced with `scipy.optimize.lsq_linear`.
- `lsqnonlin` was replaced with `scipy.optimize.least_squares`.
- The numerical structure is kept as close as possible to the original MATLAB code.

## Important caution
This is a direct scientific-code translation, not a re-derived implementation. Before using it for publication-quality results, compare the Python output against the MATLAB output for the same input files.
