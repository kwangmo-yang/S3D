
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from io_utils import read_matrix, interp_complex, nk_to_epsilon, trapz_norm


@dataclass
class S3DConfig:
    wavelength: np.ndarray
    pl_filename: str
    el_filename: str | None
    ved: float
    plqy: float
    thickness_nm: np.ndarray
    eml_position_1based: int
    ctl_position_1based: int | None = None
    ctl_scan_nm: np.ndarray | None = None
    delta_x_nm: float = 5.0


def build_epsilon(base_dir: Path, wavelength: np.ndarray) -> np.ndarray:
    nk_dir = base_dir / 'nk'

    air_w = np.array([200.0, 1920.0])
    air_n = np.array([1.003, 1.003])
    air = np.interp(wavelength, air_w, air_n).astype(complex)

    def load_eps(name: str, kind: str = 'linear', extrapolate: bool = False) -> np.ndarray:
        data = read_matrix(nk_dir / name)
        wl, eps = nk_to_epsilon(data)
        return interp_complex(wl, eps, wavelength, kind=kind, extrapolate=extrapolate)

    glass = load_eps('Glass.txt')
    ito = load_eps('ITO.txt')
    hatcn = load_eps('HAT-CN.xlsx', kind='cubic', extrapolate=True)
    bcfn = load_eps('BCFN.txt', kind='cubic', extrapolate=True)
    siczcz = load_eps('SiCzCz.csv', kind='cubic', extrapolate=True)
    msitrz = load_eps('mSiTrz.csv', kind='cubic', extrapolate=True)
    msitrz_liq = load_eps('mSiTrz_Liq_1050_1061.csv', kind='cubic', extrapolate=True)
    liq = load_eps('Liq.csv', kind='cubic', extrapolate=True)
    al = load_eps('Al.txt')
    eml = load_eps('EML_50_50_281_Blue.csv', kind='cubic', extrapolate=True)

    epsilon = np.vstack([air, al, liq, msitrz_liq, msitrz, eml, siczcz, bcfn, hatcn, ito, glass, air])
    return epsilon


def load_pl(base_dir: Path, filename: str, wavelength: np.ndarray) -> np.ndarray:
    data = read_matrix(base_dir / 'PL' / filename)
    pl = np.interp(wavelength, data[:, 0], data[:, 1])
    return trapz_norm(pl, wavelength)


def load_el(base_dir: Path, filename: str, wavelength: np.ndarray) -> np.ndarray:
    data = read_matrix(base_dir / 'EL' / filename)
    el = np.interp(wavelength, data[:, 0], data[:, 1])
    return el / np.max(el)
