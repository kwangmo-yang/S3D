# S3D_Python

## Overview
This code performs optical simulations for OLED structures to:

- Check refractive index data (n, k)
- Determine optimal CTL thickness
- Extract recombination zone (RZ) from EL spectra

---

## Requirements
Install the required packages:

pip install numpy scipy matplotlib pandas openpyxl

---

## Folder Structure
S3D_Python/
├── config.py
├── core.py
├── io_utils.py
├── ctl_thickness_determination.py
├── rz_extraction.py
├── plot_nk_current.py
├── nk/
├── PL/
└── EL/

---

## How to Run

Make sure your working directory is set to the S3D_Python folder.

### 1. Check refractive index data
python plot_nk_current.py

### 2. Determine CTL thickness
python ctl_thickness_determination.py

### 3. Extract recombination zone (RZ)
python rz_extraction.py

---

## Notes
- All scripts assume the current directory is S3D_Python
- Input data must be placed in:
  - nk/ (optical constants)
  - PL/ (PL spectrum)
  - EL/ (EL spectrum)

---

## Recommended Workflow
1. plot_nk_current.py
2. ctl_thickness_determination.py
3. rz_extraction.py
