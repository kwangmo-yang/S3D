# S3D_Python

Python tools for optical simulation and analysis of bottom-emitting OLED structures.

## What this repository does

This codebase supports three main tasks:

- plotting and checking refractive index (`n`, `k`) data,
- determining the optimal charge-transport-layer (CTL) thickness, and
- extracting the recombination zone (RZ) from electroluminescence (EL) spectra.

## Repository structure

```text
S3D_Python/
├── config.py
├── core.py
├── io_utils.py
├── plot_nk_current.py
├── ctl_thickness_determination.py
├── rz_extraction.py
├── nk/
├── PL/
└── EL/
```

## Requirements

Install the required packages with:

```bash
pip install -r requirements.txt
```

Main dependencies:

umpy==2.4.2
scipy==1.17.0
matplotlib==3.10.8
Pillow==12.1.1
pandas==3.0.0
openpyxl==3.1.5

## Input files

Place the input data in these folders:

- `nk/` for optical constants
- `PL/` for photoluminescence spectra
- `EL/` for electroluminescence spectra

## How to run

Make sure your working directory is the `S3D_Python` folder before running the scripts.

### 1) Check refractive index data

```bash
python plot_nk_current.py
```

### 2) Determine CTL thickness

```bash
python ctl_thickness_determination.py
```

### 3) Extract the recombination zone (RZ)

```bash
python rz_extraction.py
```

## Recommended workflow

1. Run `plot_nk_current.py` to verify the optical constants.
2. Run `ctl_thickness_determination.py` to identify the appropriate CTL thickness.
3. Run `rz_extraction.py` to extract the RZ from the measured EL spectrum.

## Notes

- All scripts assume relative paths from the repository root.
- `pandas` and `openpyxl` are needed to read spreadsheet-based optical-constant files such as `.xlsx`.
- `Pillow` is included for image handling and future GIF/image export workflows.
